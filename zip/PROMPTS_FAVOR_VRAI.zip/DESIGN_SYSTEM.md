# DESIGN_SYSTEM.md — Système de Design
## Favor Company International

> **Framework :** Tailwind CSS v4 + shadcn/ui  
> **Philosophie :** Moderne, professionnel, inspirant confiance — ancré dans l'identité africaine

---

## 1. Identité de Marque

### Nom
**Favor Company International**

### Positionnement
SaaS Immobilier Africain Premium — Confiance, Modernité, Accessibilité

### Valeurs Visuelles
- **Confiance** → Couleurs stables, typographie claire, espacements généreux
- **Professionnalisme** → Design épuré, hiérarchie visuelle forte
- **Modernité** → Animations subtiles, micro-interactions, glassmorphism discret
- **Accessibilité** → Contrastes conformes WCAG 2.1 AA, taille de police lisible

---

## 2. Palette de Couleurs

### Couleurs Primaires
```css
--color-primary-50:  #FFF7ED;   /* Fond très clair */
--color-primary-100: #FFEDD5;   /* Fond clair */
--color-primary-200: #FED7AA;   /* Accent clair */
--color-primary-300: #FDBA74;   /* Accent moyen */
--color-primary-400: #FB923C;   /* Orange vif */
--color-primary-500: #F97316;   /* Orange principal ← BRAND COLOR */
--color-primary-600: #EA580C;   /* Orange foncé */
--color-primary-700: #C2410C;   /* Orange très foncé */
--color-primary-800: #9A3412;   /* Brun-orangé */
--color-primary-900: #7C2D12;   /* Brun profond */
```

### Couleurs Secondaires
```css
--color-secondary-50:  #F8FAFC;
--color-secondary-100: #F1F5F9;
--color-secondary-200: #E2E8F0;
--color-secondary-300: #CBD5E1;
--color-secondary-400: #94A3B8;
--color-secondary-500: #64748B;   /* Gris ardoise ← TEXTE SECONDAIRE */
--color-secondary-600: #475569;
--color-secondary-700: #334155;
--color-secondary-800: #1E293B;   /* Bleu nuit ← TITRES */
--color-secondary-900: #0F172A;   /* Noir bleuté */
```

### Couleurs Sémantiques
```css
--color-success:  #10B981;   /* Vert — Succès, disponible */
--color-warning:  #F59E0B;   /* Ambre — Réservé, en attente */
--color-error:    #EF4444;   /* Rouge — Erreur, vendu */
--color-info:     #3B82F6;   /* Bleu — Information */
```

### Couleurs de Fond
```css
--color-bg-primary:   #FFFFFF;
--color-bg-secondary: #F8FAFC;
--color-bg-tertiary:  #F1F5F9;
--color-bg-dark:      #0F172A;   /* Dark mode */
```

---

## 3. Typographie

### Polices
```css
/* Titres — Moderne et fort */
--font-heading: 'Plus Jakarta Sans', 'Inter', system-ui, sans-serif;

/* Corps — Lisible et neutre */
--font-body: 'Inter', system-ui, -apple-system, sans-serif;

/* Monospace — Code */
--font-mono: 'JetBrains Mono', 'Fira Code', monospace;
```

### Échelle Typographique
```css
--text-xs:   0.75rem;    /* 12px — Labels, badges */
--text-sm:   0.875rem;   /* 14px — Corps secondaire */
--text-base: 1rem;       /* 16px — Corps principal */
--text-lg:   1.125rem;   /* 18px — Lead text */
--text-xl:   1.25rem;    /* 20px — Petits titres */
--text-2xl:  1.5rem;     /* 24px — Titres section */
--text-3xl:  1.875rem;   /* 30px — Titres page */
--text-4xl:  2.25rem;    /* 36px — Titres hero */
--text-5xl:  3rem;       /* 48px — Titres hero large */
--text-6xl:  3.75rem;    /* 60px — Titres XXL */
```

### Poids
```css
--font-normal:    400;
--font-medium:    500;
--font-semibold:  600;
--font-bold:      700;
--font-extrabold: 800;
```

---

## 4. Espacements

```css
/* Basé sur un système de 4px */
--space-1:  0.25rem;   /* 4px */
--space-2:  0.5rem;    /* 8px */
--space-3:  0.75rem;   /* 12px */
--space-4:  1rem;      /* 16px */
--space-5:  1.25rem;   /* 20px */
--space-6:  1.5rem;    /* 24px */
--space-8:  2rem;      /* 32px */
--space-10: 2.5rem;    /* 40px */
--space-12: 3rem;      /* 48px */
--space-16: 4rem;      /* 64px */
--space-20: 5rem;      /* 80px */
--space-24: 6rem;      /* 96px */
```

---

## 5. Composants — Spécifications

### Boutons
```tsx
// Bouton Principal
<Button variant="default">
  Réserver maintenant
</Button>
// bg-primary-500, text-white, hover:bg-primary-600

// Bouton Secondaire
<Button variant="outline">
  En savoir plus
</Button>
// border-primary-500, text-primary-500, hover:bg-primary-50

// Bouton Destructif
<Button variant="destructive">
  Supprimer
</Button>
// bg-error, text-white

// Tailles
// sm: h-8 px-3 text-sm
// default: h-10 px-4 text-sm
// lg: h-12 px-6 text-base
```

### Cards
```tsx
// Card Bien (e-commerce style)
<BienCard
  image="..."
  nom="Terrain Cocody 500m²"
  prix={45000000}
  surface={500}
  ville="Cocody"
  statut="disponible"     // badge vert
  // "réservé" → badge ambre
  // "vendu" → badge rouge
/>
// Ombre: shadow-md hover:shadow-xl
// Transition: transition-all duration-300
// Border radius: rounded-xl
```

### Badges de Statut
```tsx
// Disponible → bg-success/10 text-success border-success/20
// Réservé → bg-warning/10 text-warning border-warning/20
// Vendu → bg-error/10 text-error border-error/20
// En négociation → bg-info/10 text-info border-info/20
```

### Formulaires
```tsx
// Input standard
<Input placeholder="Votre email" />
// border-secondary-300 focus:border-primary-500 focus:ring-primary-500/20

// Label
<Label>Email *</Label>
// text-secondary-700 font-medium text-sm mb-1.5

// Message d'erreur
<p className="text-error text-sm mt-1">
  {error}
</p>
```

### Navigation
```tsx
// Navbar
// - Hauteur : 64px (desktop), 56px (mobile)
// - Position : sticky top-0 z-50
// - Background : white avec backdrop-blur
// - Ombre : shadow-sm au scroll
// - Logo : gauche
// - Liens : milieu
// - CTA (Connexion, S'inscrire) : droite

// Mobile : Menu burger → Drawer latéral
```

---

## 6. Animations

### Principes
- **Subtiles et fonctionnelles** — les animations aident la navigation, pas la décorent
- **Durée courte** : 150ms → 300ms pour les micro-interactions, 500ms→1s pour les entrées de page
- **Easing** : `ease-out` pour les entrées, `ease-in` pour les sorties

### Animations Utilisées
```css
/* Entrée d'un élément */
@keyframes slideInUp {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* Fade in */
@keyframes fadeIn {
  from { opacity: 0; }
  to   { opacity: 1; }
}

/* Pulse (loading) */
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.5; }
}

/* Hero scroll effect */
/* Parallax sur la hero section via Framer Motion */
```

### Hero Section
```tsx
// Vidéo ou image de fond en plein écran
// Overlay gradient : from-black/60 to-black/20
// Texte animé : slideInUp avec délais échelonnés
// Boutons : fadeIn après 800ms
// Scroll indicator : bounce animation

// Bibliothèque : Framer Motion
import { motion } from 'framer-motion'

<motion.h1
  initial={{ opacity: 0, y: 30 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.8, ease: 'easeOut' }}
>
  Trouvez le bien de vos rêves
</motion.h1>
```

---

## 7. Responsive Breakpoints

```css
/* Tailwind CSS v4 */
sm:   640px   /* Mobile large */
md:   768px   /* Tablette */
lg:   1024px  /* Desktop small */
xl:   1280px  /* Desktop */
2xl:  1536px  /* Desktop large */
```

### Grilles
```tsx
// Biens : 1 col mobile → 2 cols tablette → 3 cols desktop → 4 cols XL
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">

// Dashboard : sidebar fixe desktop, drawer mobile
// Sidebar width : 256px desktop
// Main content : flex-1
```

---

## 8. Icons

**Bibliothèque :** Lucide React  
**Taille standard :** 20px (corps), 24px (navigation), 16px (labels)  
**Couleur :** hérite du texte parent (`currentColor`)

```tsx
import { Home, MapPin, ChevronRight, Star, Heart } from 'lucide-react'

// Usage
<MapPin className="w-4 h-4 text-secondary-500" />
<Star className="w-5 h-5 fill-warning text-warning" />
```

---

## 9. Ombres & Bordures

```css
/* Ombres */
--shadow-sm:  0 1px 2px 0 rgb(0 0 0 / 0.05);
--shadow-md:  0 4px 6px -1px rgb(0 0 0 / 0.1);
--shadow-lg:  0 10px 15px -3px rgb(0 0 0 / 0.1);
--shadow-xl:  0 20px 25px -5px rgb(0 0 0 / 0.1);
--shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);

/* Rayons de bordure */
--radius-sm: 0.25rem;   /* 4px */
--radius-md: 0.375rem;  /* 6px */
--radius-lg: 0.5rem;    /* 8px */
--radius-xl: 0.75rem;   /* 12px */
--radius-2xl: 1rem;     /* 16px */
--radius-full: 9999px;  /* Cercle/Pilule */
```

---

## 10. Dark Mode

La plateforme supporte le dark mode via la classe `.dark` de Tailwind.

```tsx
// tailwind.config.ts
darkMode: 'class'

// Layout principal
<html lang="fr" className={isDark ? 'dark' : ''}>

// Couleurs adaptées automatiquement via CSS variables
// Les composants shadcn/ui sont dark-mode ready
```

---

## 11. Accessibilité

- Contraste minimum : 4.5:1 (texte normal), 3:1 (texte grand)
- Focus visible sur tous les éléments interactifs
- Labels aria sur tous les formulaires et boutons icon-only
- Skip to content link en début de page
- Textes alternatifs sur toutes les images
- Navigation au clavier complète

---

*Design System v1.0 — Mai 2026*  
*Figma : [Lien à ajouter]*
